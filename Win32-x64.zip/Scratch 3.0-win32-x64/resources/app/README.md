# Scratch3Builder [![Build Status](https://travis-ci.org/TheBrokenRail/Scratch3Builder.svg?branch=master)](https://travis-ci.org/TheBrokenRail/Scratch3Builder) [![Greenkeeper badge](https://badges.greenkeeper.io/TheBrokenRail/Scratch3Builder.svg)](https://greenkeeper.io/)

A Program To Package Scratch 3.0
Supports Windows, Linux, and Mac.
