# Scratch 3.0 Daily Builds

[Windows 64bit](./Win32-x64.zip)

[Windows 32bit](./Win32-ia32.zip)

[Linux 64bit](./Linux-x64.tar.gz)

[Linux 32bit](./Linux-ia32.tar.gz)

[Linux ARMV7L](./Linux-armv7l.tar.gz)

[Mac 64bit](./Mac-x64.tar.gz)
